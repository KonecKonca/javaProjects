CREATE PROCEDURE getFromEmployee(IN id INT)
  BEGIN
    SELECT * FROM employee WHERE emp_id = id;
  END;


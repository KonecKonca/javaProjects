CREATE PROCEDURE getCountEmployee(OUT returnVar INT)
  BEGIN
    SELECT count(*) into returnVar FROM employee;
  END;


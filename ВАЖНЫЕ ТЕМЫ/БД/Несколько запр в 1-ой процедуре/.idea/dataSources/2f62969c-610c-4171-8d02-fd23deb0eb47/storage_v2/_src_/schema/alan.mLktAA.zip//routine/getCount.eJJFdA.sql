CREATE PROCEDURE getCount()
  BEGIN
    SELECT count(*) from employee;
    SELECT count(*) FROM department;
  END;

